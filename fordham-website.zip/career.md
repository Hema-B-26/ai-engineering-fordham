https://www.fordham.edu/career

# Fordham Career Center

![Company logos of the Career Center's 2025 Signature Partners.](/media/home/departments-centers-and-offices/career-center/Sig-Partners-2025.png)


We serve students and alumni of Fordham College Rose Hill, Fordham College Lincoln Center, Gabelli School of Business Undergraduate Programs, School of Professional and Continuing Studies, Graduate School of Arts and Sciences, and Graduate School of Education through one-on-one appointments, professional development workshops, events, and specialized resources. We also partner with employers and industry leaders to demonstrate the value and relevance of a Jesuit education.