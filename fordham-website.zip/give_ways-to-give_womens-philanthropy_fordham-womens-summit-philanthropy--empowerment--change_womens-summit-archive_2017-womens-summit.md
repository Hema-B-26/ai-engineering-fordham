https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2017-womens-summit

# 2017 Women's Summit

![Women's Philanthropy Summit Logo](/media/review/content-assets/migrated/images/Women_s_Philanthropy_Summit_Logo___SM_1.png)

**November 6, 2017**

175 Fordham women came together on the Lincoln Center Campus for a half day of community building, networking, and philanthropy.

We saw [speakers who shared insights on the collective power of women’s giving to change the world](/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2017-womens-summit/2017-womens-summit-videos/) and we [celebrated Fordham women who inspire us with their philanthropy](/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2017-womens-summit/pioneering-women-in-philanthropy-at-fordham-2017/).

We also explored ways we can continue to engage with each other and support Fordham projects of our choosing.