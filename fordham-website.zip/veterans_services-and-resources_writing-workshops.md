https://www.fordham.edu/veterans/services-and-resources/writing-workshops

# Writing Workshops

## "Because every veteran has a story"


The Veterans Writing Workshop gives veterans the tools and confidence they need to bring their stories to life. Veterans will meet once a week for valuable peer support and feedback.

If you are a veteran interested in finding a supportive community of writers to help you tell your story, we encourage you to join us. To register for the FREE workshops email: [[email protected]](/cdn-cgi/l/email-protection#ec85828a83ac9a8998899e8d829f9b9e859885828b9b839e879f84839cc2839e8b) or call 917-803-2391.

Learn more about the [Veterans Writing Workshop](http://www.veteranswritingworkshop.org/).