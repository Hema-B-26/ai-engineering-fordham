https://www.fordham.edu/veterans/services-and-resources/edge4vets-transition-support-workshops

# Edge4Vets Transition Support Workshops

In the military, you learned critical strengths, including the ability to change with the circumstances, the engagement that enables you to work with others, the pro-action that helps you get things done, and the optimism that keeps you positive. And through the workshops that make up our Edge4Vets program, you'll see how to use these leadership traits to succeed in an academic environment.

With the community at [Edge4Vets](http://reclaimingthesky.com/), you can share your personal transition story, discuss ongoing challenges, and get tips from other veterans. This one-of-a-kind program is just one of the ways Fordham helps veterans transition to academic life and achieve their goals.