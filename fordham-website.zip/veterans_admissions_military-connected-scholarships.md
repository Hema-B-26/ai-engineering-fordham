https://www.fordham.edu/veterans/admissions/military-connected-scholarships

# Military Connected Scholarships

There are countless scholarship opportunities for veterans and veteran dependents that are offered both by the United States Department of Veterans Affairs (VA) and private foundations.

Learn more about [VA Scholarships](/veterans/admissions/military-connected-scholarships/va-scholarships/) and [Private Scholarships](/veterans/admissions/military-connected-scholarships/private-scholarships/).