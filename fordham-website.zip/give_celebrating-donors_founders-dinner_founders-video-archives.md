https://www.fordham.edu/give/celebrating-donors/founders-dinner/founders-video-archives

# Founder's Dinner Video Archive

Founder's 2024

Founder's 2023

Founder's 2021: Cura Personalis | For Every Fordham Student (Campaign Launch)

Founder's 2020: Faith & Hope | The Campaign for Financial Aid (Campaign Close)

Founder's 2019

Founder's 2018

Founder's 2017: Faith & Hope | The Campaign for Financial Aid (Campaign Launch)

Founder's 2016

Founder's 2015

Founder's 2014: Excelsior | Ever Upward | The Campaign for Fordham (Campaign Close)

Founder's 2013

Founder's 2012

Founder's 2011

Founder's 2010

Founder's 2009: Excelsior | Ever Upward | The Campaign for Fordham (Campaign Launch)