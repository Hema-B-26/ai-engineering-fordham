https://www.fordham.edu/it_services

# IT Services

**Administrative Services**

Essential resources for everyone at Fordham.

**Communication & Collaboration**

Share information and connect with others.

-
[Fordham Messaging Platform](/information-technology/standard-software/fordham-messaging/)(FMP)[Google Meet](/information-technology/standard-software/google-workspace/#d.en.90284)(Video Conferencing)[Telephone service](/information-technology/it-services/unified-communications/)(Unified Communications)[Zoom](/information-technology/standard-software/virtual-classes-and-meetings/zoom-services/)(Video Conferencing)

**Information Security**

Keep University data and systems secure.

**Teaching and Learning**

Resources for classrooms and online

**Research Computing**

For creating and disseminating knowledge.

**Student Resources**

For academics and campus life.

**IT Services and Support**

Resources for using University systems and applications.

**IT Professional Services**

![Two people with speech bubble](/media/home/commonly-used-images/icons/Advisor-Icon.png)

For specific projects and knowledge development.

**Network and Infrastructure**

Wired, WiFi, cloud, and platform services and applications