https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/pioneering-women-in-philanthropy-at-fordham/2025-pioneering-women-in-philanthropy-

Meet Our 2025 Honorees:

Jane Bartnett, MC '76

Betty Burns, FCLC '83

Deneen Donnley, LAW ’92

Liz Nesvold, GABELLI '95