https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2024-womens-summit/2024-womens-summit-sessions

# 2024 Women's Summit Sessions

**Student Scholarship Speaker: Makeda Byfield, FCRH '25**

![](/media/home/departments-centers-and-offices/give/Makeda-Byfield.jpg)

Makeda Byfield is a Social Work major at Fordham College at Lincoln Center and a recipient of the Riversville Foundation Scholarship. Overcoming homelessness, she commuted from a shelter while caring for her younger siblings and working multiple jobs. Active on campus, she is part of CSTEP, the Academic Integrity Committee, and is president of the Social Work Society. Makeda volunteered as a court advocate for youth and interned at the Bronx Leadership & Organizing Center. Passionate about breaking cycles of poverty, she is completing 450+ hours of field placement, surpassing requirements, and has started a student social work club.