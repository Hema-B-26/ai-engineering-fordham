https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2024-womens-summit/2024-pioneering-women-in-philanthropy-at-fordham

# 2024 Pioneering Women in Philanthropy at Fordham

The Pioneering Women in Philanthropy Award celebrates the honorees’ professional and trailblazing accomplishments as well as their transformative gifts and service to Fordham University. Their wisdom, remarkable careers, and devotion to Fordham serve as inspiration for the women of the Fordham community to lead lives dedicated to the betterment of the world in which we live.Meet Our 2024 Honorees:

[Jane Bartnett](/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2024-womens-summit/2024-pioneering-women-in-philanthropy-at-fordham/jane-bartnett-mc-76/), MC '76

[Mary Hamilton](/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2024-womens-summit/2024-pioneering-women-in-philanthropy-at-fordham/mary-hamilton-phd-fac/), Ph.D., FAC

[Carol Robles-Román, Esq.](/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2024-womens-summit/2024-pioneering-women-in-philanthropy-at-fordham/carol-robles-roman-esq-fclc-83/), FCLC '83, *posthumously*

[Adriana Trigiani](/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2024-womens-summit/2024-pioneering-women-in-philanthropy-at-fordham/adriana-trigiani-par/), PAR