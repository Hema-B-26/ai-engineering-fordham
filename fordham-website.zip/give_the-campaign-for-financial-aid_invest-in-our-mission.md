https://www.fordham.edu/give/the-campaign-for-financial-aid/invest-in-our-mission

# Invest in Our Mission

Financial aid and scholarships are an expression of Fordham’s values: Not only do they enable talented and motivated students of modest means to attend the University, but they are a tangible manifestation of the Fordham family’s devotion to each other.

The benefits of financial aid accrue not only to its recipients but also to the culture at large. Because of financial aid, there are more voices in the national conversation, more ideas, and more solutions.

Joseph M. McShane, S.J., President, Fordham University