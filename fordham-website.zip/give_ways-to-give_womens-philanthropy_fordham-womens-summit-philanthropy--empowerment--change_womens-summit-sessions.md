https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-sessions

# 2025 Fordham Women’s Summit Sessions

**Student Scholarship Speaker: Juliana Tulio, GABELLI '26**



**Juliana Tulio, GABELLI ’26**, is currently studying marketing at the Rose Hill campus. She chose marketing to understand and apply consumer psychology, specifically aiming to create messaging that promotes sustainability and inclusion. The Warrington, Pennsylvania, native currently serves as co-president of Spes Nova, where she supports global artisans through micro-financing, and is an active member of the Fordham Marketing Association and Smart Woman Securities. She is also part of the Marketing Scholars program and served as an Orientation Leader this year.