https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2019-womens-summit/2019-womens-philanthropy-summit-panels-and-workshops/2019-womens-philanthropy-summit-moderators/justine-franklin

# Justine Franklin

![Justine Franklin](/media/review/content-assets/migrated/images/Justine_Franklin.jpg)

Justine C. Franklin is a senior director of development for major gifts at Fordham University, where she has worked for 13 years. Previously, she held various development positions over 11 years at the American Red Cross in Ohio and in New York. Justine holds a B.A. from Boston College and an M.A. in literature from San Francisco State University. She is married and has one son, Noah, who is in fifth grade. She and her family live in West Harlem and go upstate for outdoor fun in all seasons. Justine has worked with Rose Marie Bravo for more than 10 years, and she is honored to be interviewing her at the 2019 Women’s Philanthropy Summit.