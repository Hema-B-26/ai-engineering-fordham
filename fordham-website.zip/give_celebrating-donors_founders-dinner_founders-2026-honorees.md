https://www.fordham.edu/give/celebrating-donors/founders-dinner/founders-2026-honorees

# The Fordham Founder's Award

With the Fordham Founder’s Award, we seek to recognize individuals whose personal and professional lives reflect the highest aspirations of the University’s defining traditions, as an institution dedicated to wisdom and learning in the service of others. They are designated Founders of Fordham not only for their own achievements and contributions to the University, but also because they stand as exemplars of the renewal of the University in its identity and mission by different generations of Fordham graduates.