https://www.fordham.edu/give/ways-to-give/institutional-giving/resources-for-proposal-writing/proposal-writing-guides

# Resources for Proposal Writing

## Proposal Writing Guides

[What Should be Included in a Letter of Inquiry](https://grantspace.org/resources/knowledge-base/letters-of-inquiry/) Knowledge Base, Grantspace by Candid

[12 Quick Tips for Better Grant Writing](https://blog.firespring.com/12-quick-tips-for-better-grant-writing/) Kelly Medwick, Firespring.com

[What Should be Included in a Letter of Inquiry](https://grantspace.org/resources/knowledge-base/letters-of-inquiry/) Knowledge Base, Grantspace by Candid

[12 Quick Tips for Better Grant Writing](https://blog.firespring.com/12-quick-tips-for-better-grant-writing/) Kelly Medwick, Firespring.com