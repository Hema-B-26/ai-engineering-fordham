https://www.fordham.edu/veterans/student-veterans-of-america/svaf-leadership

# SVAF Leadership

## Meet the Team


#### Jorge A. Ferrara

![Headshot of Jorge Ferrara](/media/home/departments-centers-and-offices/veterans/military-and-veteran-images/Jorge-headshot.jpg)


*President*

#### Angel Diaz

![Angel Diaz Headshot](/media/home/departments-centers-and-offices/veterans/military-and-veteran-images/Angel-headshot_172x172.jpeg)


*Vice President / Alumni Relations Liaison*

#### Rico Lucenti

![Rico Lucenti Headshot](/media/home/departments-centers-and-offices/veterans/military-and-veteran-images/Rico-headshot.jpg)


*Leadership Fellow / Alumni Relations Liaison*

#### Ashton Bracey

![Ashton Bracey headshot](/media/home/departments-centers-and-offices/veterans/military-and-veteran-images/Ashton-headshot.jpg)


*Leadership Fellow*

#### Jasmine Dean

*Vice President of Media and Communications*

#### Angel Rivera

![Angel Rivera headshot](/media/home/departments-centers-and-offices/veterans/military-and-veteran-images/Angel-Rivera-headshot_179x179.jpeg)


*Vice President of Disability Services*

#### Huy Le

![Huy Le headshot](/media/home/departments-centers-and-offices/veterans/military-and-veteran-images/Huy-headshot_169x169.jpeg)


*Graduate School Liaison*

#### Sebastian Oprea

![Sebastian Oprea headshot](/media/home/departments-centers-and-offices/veterans/military-and-veteran-images/Sebastian-headshot_258x258.png)


*Policy Liaison*

#### Sofia Dickerman

![Sofia Dickerman headshot](/media/home/departments-centers-and-offices/veterans/military-and-veteran-images/IMG_2021_300x300.jpeg)


*Creative Director*

#### Emily Donovan

*Creative Director*

#### Isabel Adkins

*Creative Director*