https://www.fordham.edu/library

My Account

Ask a Librarian


Collections

Resources

Library Services

Research Support

Library Instruction

About Us

Follow Us

By Hannah Lettieri, Emerging Technologies Librarian After seven years of posts, stories, and updates here on Fordham Library News, we’re writing our final chapter on

Read The Full Story Arrow right icon

Explore our curated LGBTQ+ book and film display, highlighting diverse stories of identity, resilience, and community. This collection invites reflection, celebration, and deeper understanding during Pride and beyond.

Exciting changes are coming soon to EBSCOhost databases and OneSearch, Fordham Libraries’ central discovery service! Starting May 22, 2025, users may notice a new look and feel when using OneSearch and EBSCOhost databases.This updated user interface includes enhanced displays, increased personalization, intuitive searching, and much more.

Within the Fordham Libraries student worker class of 2025, two of our students are about to embark on their journeys of becoming none other than… librarians! We sat down and chatted with these two soon-to-be grads to reflect upon their time working at the Walsh Library, and look forward to the future as they prepare for library school and get ready to become the librarians of tomorrow!

Our latest blog post series, Behind the Scenes, takes our readers through and around various departments of the Fordham University Libraries. Today, we sit down with our Archives & Special Collections Librarian, Gabriella DiMeglio. Enjoy this super-exclusive backstage pass inside the academic library world!