https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/pioneering-women-in-philanthropy-at-fordham/2025-pioneering-women-in-philanthropy-/betty-burns-fclc-83

# Betty Burns, FCLC '83

![](/media/home/departments-centers-and-offices/give/View-recent-photos-Cropped.jpg)


Burns also established the Elizabeth Burns Endowed Fund for Mission and Ministry, the John and Catherine Burns Endowed Bachelor of Fine Arts Scholarship, the Burns Family Endowed Artistic Merit Scholarship Fund, and the Louis Calder/Elizabeth A. Burns Endowed Scholarship Fund.

She is a retired senior vice president of Capital Guardian Trust, part of the Capital Group of Companies, where she worked for 16 years before retiring in 2005. Before working there, Burns worked at Time Warner, Inc. as the assistant treasurer in the company's corporate finance group, where she was responsible for the company’s pension, 401(k), and corporate cash portfolios.

Burns serves on the board of United Neighborhood Centers of Northeastern Pennsylvania and is a founding member of Nativity Miguel School of Scranton. She currently resides in Blakely, Pennsylvania, and Charleston, South Carolina.