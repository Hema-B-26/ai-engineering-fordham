https://www.fordham.edu/center-for-jewish-studies/academics-and-research/faculty/hagit-halperin

# Hagit Halperin

-
Hagit holds a master's degree in Jewish Art and Visual Culture from Jewish Theological Seminary in NY, as well as a bachelor's in Restoration, from Fashion Institute of Technology in New York. She holds an art teaching certificate from Ha’Midrashah Le'Omanut, an Israeli college for art education. Hagit has been teaching Hebrew at Fordham University since the Fall Semester of 2019. In addition, Hagit currently teaches the IB program at Dwight High School, and at JTS's Ivry Prozdor program. Hagit has been leading museum tours, in Hebrew, around New York, mainly for Ha-Ulpan students - since 2006.