https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2018-womens-summit/2018-womens-philanthropy-summit-panel-sessions/keeping-the-faith-engaging-the-next-generation-in-conversations-of-spirituality-and-service

# 2018 Keeping the Faith: Engaging the Next Generation in Conversations of Spirituality and Service

Americans are increasingly identifying as religious "nones." But these women have nevertheless been able to tap into the next generation's sense of spirituality and social justice.

### Moderator

[Christine Firer Hinze](/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2018-womens-summit/2018-womens-philanthropy-summit-panel-sessions/2018-womens-philanthropy-summit-moderators/christine-hinze/), Professor of Christian Ethics and Director of the Curran Center for American Catholic Studies, Fordham University

Christine Firer Hinze is a professor of Christian ethics and the director of the Curran Center for American Catholic Studies at Fordham University and is currently the vice president of the Catholic Theological Society of America.

![Christine Firer Hinze](/media/review/content-assets/migrated/images/Fordham_Christine_Firer_Hinze.jpg)


### Panelists

[Anne Conroy](/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2018-womens-summit/2018-womens-philanthropy-summit-panel-sessions/2018-womens-philanthropy-summit-panelists/anne-conroy/), Director of Development and Communications, Center for Family Representation

Anne Conroy is the director of development and communications at the Center for Family Representation, where she is responsible for communication strategy and private fundraising, including events, individual contributions, and foundation grants.

![Anne Conroy](/media/review/content-assets/migrated/images/Anne_Conroy.jpg)


[Roxanne De La Torre](/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2018-womens-summit/2018-womens-philanthropy-summit-panel-sessions/2018-womens-philanthropy-summit-panelists/roxanne-de-la-torre/), Director of Campus and Community Leadership, Center for Community Engaged Learning, Fordham University

Roxanne De La Torre is the director of campus and community leadership for Fordham University’s Center for Community Engaged Learning. Born and raised in Queens, De La Torre is the first-born daughter of Filipino immigrants. She received her bachelor’s degree from Fordham University, with a focus on communication and media studies and theology.

![Roxanne De La Torre](/media/review/content-assets/migrated/images/Roxanne_De_La_Torre.jpg)


[Anastasia Economos](/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2018-womens-summit/2018-womens-philanthropy-summit-panel-sessions/2018-womens-philanthropy-summit-panelists/anastasia-economos/), Partner, Financial Accounting Advisory Services, Ernst & Young

Anastasia Economos is a partner within Ernst & Young LLP’s Financial Accounting Advisory Services practice, where she advises global organizations on the impact of regulatory and transformational change on the accounting and financial reporting function and related systems and processes.

![Meet Anastasia Economos](/media/review/content-assets/migrated/images/Anastasia_Economos.jpg)


[Laura Risimini](/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2018-womens-summit/2018-womens-philanthropy-summit-panel-sessions/2018-womens-philanthropy-summit-panelists/laura-risimini/), Foundation Manager, The Sister Fund

Laura Risimini is the foundation manager at The Sister Fund, a private family foundation/women’s fund, which historically has focused on the importance of the values and voices of women of faith. Currently, it is in the process of broadening its focus to include the interests of The Sister Fund’s donor family.

![Meet Laura Risimini](/media/review/content-assets/migrated/images/Laura_Risimini.jpg)