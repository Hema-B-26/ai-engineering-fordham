https://www.fordham.edu/give

# Give

## Join Us in Renewing Our Distinctive Jesuit Educational Experience

Never before has Fordham University held such potential to prepare future generations of leaders whose intellect, energy, ethical rigor and generosity of spirit can change the world.

Your gift of any amount helps Fordham guarantee that we will fulfill this promise.

![Asian Student Backlit with Laptop](/media/review/content-assets/migrated/images/KGamble_090814_6625_1.jpg)


## We Couldn't Do it Without You!

![](/media/review/content-assets/migrated/images/Campus-Center_Exterior-MD.jpg)


Together, your gifts allow Fordham University to maintain rigorous standards of academic and research excellence. It is our mission to remain committed to the discovery of wisdom and the transmission of learning, preparing each of our students for leadership in a global society.

[Learn more about some of the initiatives bolstered by your support](/give/celebrating-donors/your-impact/)