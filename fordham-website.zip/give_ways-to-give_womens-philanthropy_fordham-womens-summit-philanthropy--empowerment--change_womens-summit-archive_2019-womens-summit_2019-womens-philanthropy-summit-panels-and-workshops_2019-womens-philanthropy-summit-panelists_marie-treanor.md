https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2019-womens-summit/2019-womens-philanthropy-summit-panels-and-workshops/2019-womens-philanthropy-summit-panelists/marie-treanor

# Marie Treanor

![Panelist Marie Treanor](/media/review/content-assets/migrated/images/Marie_Treanor.jpg)

Marie Treanor, PAR

Marie sits on the Fordham University President’s Council and on the social enterprise board of the Light House Homeless Prevention and Support Center in Annapolis, Maryland. She is a former chair of the Fordham University Parents’ Leadership Council, and both her sons are Fordham Rams. Jack graduated from the Gabelli School of Business in 2017 and received his master’s in accounting from the Gabelli School of Business in 2018. Ricky is a current a senior at the Gabelli School of Business at Rose Hill.

Marie enjoys life by the water and supports coral reef conservation efforts in Maryland and Florida. She is a passionate advocate for breaking the cycle of homelessness and making a college education more accessible to all qualified students.