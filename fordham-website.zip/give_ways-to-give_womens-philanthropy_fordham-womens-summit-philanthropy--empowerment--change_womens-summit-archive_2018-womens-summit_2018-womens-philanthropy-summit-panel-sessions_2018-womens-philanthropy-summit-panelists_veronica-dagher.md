https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2018-womens-summit/2018-womens-philanthropy-summit-panel-sessions/2018-womens-philanthropy-summit-panelists/veronica-dagher

# Veronica Dagher

![Meet Veronica Dagher](/media/review/content-assets/migrated/images/Veronica_Dagher.jpg)

Veronica Dagher, GABELLI ’00, ’05

Veronica Dagher is an award-winning senior wealth management reporter for *The Wall Street Journal*. She is the co-creator, host, and co-producer of the top-rated podcast *The Wall Street Journal’s Secrets of Wealthy Women*, where she interviews some of the best-known women in business, including Gloria Steinem, Bobbi Brown, and Rebecca Minkoff. Dagher co-produces and hosts videos for wsj.com and is a regular guest on the Fox Business Network, where she speaks about personal finance, markets, and the economy. She is a frequent panel moderator and emcee. She received her M.B.A. from Fordham University and is a volunteer anti-human-trafficking educator for LifeWay Network.