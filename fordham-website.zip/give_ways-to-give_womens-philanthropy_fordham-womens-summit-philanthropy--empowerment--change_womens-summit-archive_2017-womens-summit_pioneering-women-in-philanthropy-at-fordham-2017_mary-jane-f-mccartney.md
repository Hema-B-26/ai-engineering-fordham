https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2017-womens-summit/pioneering-women-in-philanthropy-at-fordham-2017/mary-jane-f-mccartney

# Mary Jane F. McCartney

**Mary Jane F. McCartney, TMC ’69**, earned her bachelor’s in mathematics as part of the second graduating class of Thomas More College. She went on to serve as Con Edison’s first female senior vice president of gas operations from 1993 until her retirement in 2009. Among many passions, she has been a trustee of the New York Hall of Science since 1992 and serves on Fordham’s STEM Council, the Fordham College at Rose Hill Board of Visitors, and Fordham’s President’s Council.![Mary Jane McCartney pioneering in philanthropy](/media/review/content-assets/migrated/images/Mary_Jane_McCartney-2.jpg)


She and her husband, George McCartney, FCRH ’68, have endowed three scholarships at Fordham, one for Ailey/Fordham dance majors, another for undergraduate science research, and the last for Fordham’s neediest students.