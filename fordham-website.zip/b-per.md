https://www.fordham.edu/b-per

### Welcome! The **Bronx Personality **(**B-PER) Lab** at Fordham University studies the development of borderline personality disorder, anxiety, and depression.

**Bronx Personality**(

**B-PER) Lab**at Fordham University studies the development of borderline personality disorder, anxiety, and depression.