https://www.fordham.edu/families/our-team

Jenn Harris

Senior Director of Development, Parent and Family Philanthropy[email protected]

Max Ickes

Associate Director of Development, Parent and Family Philanthropy[email protected]

Cate Eggers

Development Coordinator, Parent and Family Philanthropy[email protected]