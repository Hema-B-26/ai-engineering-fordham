https://www.fordham.edu/center-for-jewish-studies/lectures-and-events

# Lectures and Events

## Join the Conversation

Thanks to innovative public programs and cross-institutional partnerships Jewish Studies at Fordham University has become an important venue for conversations and dialogue between the larger scholarly and lay communities.

We invite you to join us at one of our upcoming events.