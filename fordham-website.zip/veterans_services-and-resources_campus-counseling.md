https://www.fordham.edu/veterans/services-and-resources/campus-counseling

# Campus Counseling

Fordham's Counseling and Psychological Services is here to serve the mental health needs of those in the Fordham community. These services are available to Fordham students and the campus community for personal issues in any aspect of their lives.

If you need to Discuss...

- Feelings of depression
- Sense of anxiety
- How to manage stress
- Lack of focus

Visit the Campus
[Counseling Services](/student-life/safety-health-and-wellness/counseling-and-psychological-services/).