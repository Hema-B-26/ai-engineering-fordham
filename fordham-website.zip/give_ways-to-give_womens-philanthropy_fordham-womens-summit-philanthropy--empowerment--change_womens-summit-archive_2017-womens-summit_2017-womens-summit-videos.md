https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2017-womens-summit/2017-womens-summit-videos

# 2017 Women's Summit Videos

Women comprise an important social and economic resource, in not only investing in financial assets, but also through the impact that their economic power has on the well-being of our world.


Mary Barneby, GABELLI ’80, CEO of the Girl Scouts of Connecticut


Leadership is more than what we do. It’s who we are and how we give back. It’s how we can create change that matters.

Mary Lou Quinlan, GABELLI ’82, Author, Actor, Entrepreneur, Marketer, Speaker


Together, we can create a path for women in the Fordham community to make an impact individually but also collectively.

Susan Conley Salice, FCRH '84, Philanthropist