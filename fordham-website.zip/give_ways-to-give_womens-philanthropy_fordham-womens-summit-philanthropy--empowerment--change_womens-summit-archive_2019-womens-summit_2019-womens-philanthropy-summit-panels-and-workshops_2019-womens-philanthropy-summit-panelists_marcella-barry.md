https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2019-womens-summit/2019-womens-philanthropy-summit-panels-and-workshops/2019-womens-philanthropy-summit-panelists/marcella-barry

# Marcella Barry

![Panelist Marcella Barry](/media/review/content-assets/migrated/images/Marcella_Barry.jpg)

Marcella Barry, FCRH ’92, GSE ’96

Marcella Barry, FCRH ’92, GSE ’96, serves as the chief human resources officer at Design Within Reach and Herman Miller Retail. Marcella joined Design Within Reach (DWR) in September 2010; since then she has been a lead executive on change management as the company evolved from a modern furniture company to the leading authority on authentic modern design. In 2014, Design Within Reach was acquired by Herman Miller, the global design manufacturer. Throughout her tenure, DWR was named one of the top places to work in Connecticut by Hearst Media Services, and the Design Within Reach HR team received the Southern Connecticut Society for Human Resource Management HR Team of the Year Award.

Prior to joining Design Within Reach, Marcella served as vice president of human resources at Adaptive Marketing, a consumer marketing services company, and served in various human resources capacities at Avon Products and Bally of Switzerland, the luxury and leather retailer. She earned her bachelor’s degree as well as her master’s degree in adult education and human resources development at Fordham University. She is a member of Fordham’s President’s Council.

Marcella has received her senior professional in human resources certification and also holds an executive program certificate from Yale University School of Management. She is a recent graduate of the Higher Ambition Leadership Institute.

Prior to joining Design Within Reach, Marcella served as vice president of human resources at Adaptive Marketing, a consumer marketing services company, and served in various human resources capacities at Avon Products and Bally of Switzerland, the luxury and leather retailer. She earned her bachelor’s degree as well as her master’s degree in adult education and human resources development at Fordham University. She is a member of Fordham’s President’s Council.

Marcella has received her senior professional in human resources certification and also holds an executive program certificate from Yale University School of Management. She is a recent graduate of the Higher Ambition Leadership Institute.