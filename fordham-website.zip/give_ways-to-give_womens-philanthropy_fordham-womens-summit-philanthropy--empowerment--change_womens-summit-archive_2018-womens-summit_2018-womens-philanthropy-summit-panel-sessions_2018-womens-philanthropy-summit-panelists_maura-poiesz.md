https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2018-womens-summit/2018-womens-philanthropy-summit-panel-sessions/2018-womens-philanthropy-summit-panelists/maura-poiesz

# Maura Poiesz

![Maura Poiesz](/media/review/content-assets/migrated/images/Maura_Poiesz.jpg)

Maura McGourty-Poiesz, FCRH ’90, GABELLI ’92

Maura Poiesz is an executive director at UBS Financial Services and serves as the branch manager of the Warren, New Jersey, office. She started as a trainee in 1993 with Prudential Securities in Danbury, Connecticut. After five years as a financial adviser, she was asked to enter into the management trainee program at Prudential. For the next two years, she was a national training officer in New York City. In 2000, Poiesz left Prudential Securities for Smith Barney, joining as an assistant branch manager in its flagship branch in New York City. In 2010, she became the branch manager of Smith Barney in Little Falls, New Jersey, and was later promoted to run the Morristown, New Jersey, branch.

Poiesz joined UBS in 2012 to start the new Short Hills, New Jersey, branch as the producing branch manager. After 18 months she was promoted and asked to relocate to the Warren, New Jersey, branch. Her most recent accomplishment is her nomination to the UBS Leadership Advisory Council by the firm’s senior management.

After graduating from Fordham University with a B.A. in political science, Poiesz earned a master’s degree in business administration–finance, also from Fordham. She currently serves on the University’s President’s Council.

Poiesz lives in New Providence, New Jersey, with her husband, David, and their two daughters, Brooke and Gillian.