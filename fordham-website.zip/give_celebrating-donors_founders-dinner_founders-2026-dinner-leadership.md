https://www.fordham.edu/give/celebrating-donors/founders-dinner/founders-2026-dinner-leadership

# Founder's 2026 Dinner Leadership

### Founder’s 2026 | Dinner Co-Chairs

Kim Bepler ’22 Hon. LHD

Catherine A. Blaney-Petralia ’86 and Bloomberg Philanthropies

Emanuel (Manny) Chirico ’79, PAR, and Joanne M. Chirico, PAR

Gerald C. Crotty ’73, PAR, and Lucille O. Crotty, PAR

Maurice J. Cunniffe ’54 and Carolyn Dursi Cunniffe ’71 PhD

Robert D. Daleo ’72 and Linda Daleo

Mario J. Gabelli ’65 and Regina M. Pitaro ’76, and Gabelli Funds

Teresa Heitsenrether ’87 and Robert Heitsenrether

Darlene Luccio Jordan ’89 and Gerald R. Jordan Jr.

Ann E. Nugent, PAR and Christian C. Nugent ’99 JD, PAR

Armando Nuñez ’82

Robert J. O'Shea ’87, PAR, and Michele K. O'Shea ’88, PAR

James S. Rowen VII ’86, ’98 MBA and Diane P. Rowen

Dennis G. Ruppel ’68 and Patricia Ann Ruppel

Mary Anne Sullivan ’73 and Larry D. Petro

Peter J. Zangari ’89 and Jennifer A. Zangari

### Founder’s 2026 | Dinner Committee

Carolyn M. Albstein ’82 MBA, PAR, and Andrew W. Albstein ’81 JD, PAR

Don Almeida ’73 and Gail Feeney Almeida

Terence P. Begley ’86, PAR, and Tracy A. O’Neill ’87, PAR

Rosemary T. Berkery and Robert J. Hausen

Robert Boller ’99 and Jennifer Boller

James E. Buckman ’66, PAR, and Nancy M. Buckman, PAR

Ulderico Calero Jr. ’90 and Nancy Calero

Robert E. Campbell ’55 and Joan M. Campbell

Vincent R. Cappucci ’81, ’84 JD, PAR, and Anna E. Cappucci ’83, PAR

Todd G. Cosenza ’95, ’98 JD and Elizabeth Pinho Cosenza ’98

Sheryl Sillery Dellapina ’87, PAR, and Jeffrey Dellapina, PAR

Ronald A. DePinho, MD, ’77, PAR, and Lynda Chin, PAR

Rose F. DiMartino ’79 MA and Karen Sue Smith

Lori Cruz Doty, PAR, and Steve Doty, PAR

William Doty

Michael J. Dowling ’74 MSW and Kathleen Dowling

Thomas J. Durkin ’04 and Stephanie E. Durkin

Christ H. Economos and Anastasia Economos

Ignacio R. Fernández de Lahongrais ’87, PAR

Anthony J. Ferrante ’01, ’04 MS

Christopher F. Fitzmaurice ’84, PAR, and Alison J. Fitzmaurice, PAR

Robert C. Gallé ’92 and Katherine H. Gallé ’92

Guthrie Garvin ’99 and Claire Garvin

Michael A. Gatto, PAR and Mary Kay Gatto, PAR

Honora F. Ahern Grose ’84 MBA and Madison F. Grose

Colleen M. Jones ’88 MBA

Jacob M. Jordan ’09 and Marta Saurina Pradas

V. John Kriss ’62 and Sandra E. Kriss

William J. Loschert, KSG, ’61

John L. Lumelleau ’74 and Loretta Franklin Lumelleau

Kathleen H. MacLean ’75, PAR, and Brian W. MacLean ’75, PAR

John C. McGinley ’94 and Heather J. McGinley ’94

Henry S. Miller ’68, PAR, and Barbara B. Miller, PAR

Cathy E. Minehan

Paul J. Napoli ’89, PAR, and Marie Napoli, PAR

Maria del Pilar Ocasio-Douglas ’88, PAR, and Gary Douglas, PAR

Valerie Irick Rainford ’86 and Anthony Rainford

Mark C. Smith ’04 and Jaccara Smith

Donna O. Smolens ’79, ’81 MA, PAR, and Robert Smolens, PAR

Margaret M. Smyth ’85, PAR, and Bernard G. Smyth ’85, PAR

David M. Tanen ’96 JD

William J. Toppeta ’70, PAR, and Debra J. Toppeta, PAR

Mario P. Torsiello ’78 and Jennifer Grace Torsiello