https://www.fordham.edu/families/important-dates

# Important Dates for Parents and Families

##### Global Transition Program for New Undergraduate International Students

Wednesday, August 20, 2025 - Saturday, August 23, 2025

##### New Student Orientation for All Colleges/Campuses (families welcome on Sunday)

Sunday, August 24, 2025 - Tuesday, August 26, 2025

##### Fall Semester Classes Begin

Wednesday, August 27, 2025

##### Fall Family Weekend

Friday, October 24, 2025 - Sunday, October 26, 2025

##### Thanksgiving Break

Wednesday, November 26, 2025 - Sunday, November 30, 2025

##### Winter Break

Saturday, December 20, 2025 - Sunday, January 11, 2026

##### Spring Semester Classes Begin

Monday, January 12, 2026

##### Spring Break

Saturday, March 7, 2026 - Sunday, March 15, 2026

##### Easter Break

Thursday, April 2, 2026 - Monday, April 6, 2026

##### University Commencement

Saturday, May 16, 2026