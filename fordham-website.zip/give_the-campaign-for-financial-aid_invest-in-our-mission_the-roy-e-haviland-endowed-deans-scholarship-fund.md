https://www.fordham.edu/give/the-campaign-for-financial-aid/invest-in-our-mission/the-roy-e-haviland-endowed-deans-scholarship-fund

# The Roy E. Haviland Endowed Dean’s Scholarship Fund

![Doreen Prinzo](/media/review/content-assets/migrated/images/FH_Haviland_Scholarship.jpg)


### Scholarship Enshrines Veteran’s Character

When the Vietnam War ended, Roy Haviland’s family thought they would soon be welcoming home their son, a Navy pilot and 1969 Fordham graduate. But then tragedy struck—Haviland was killed during a reconnaissance flight soon after the peace agreement had been signed. His sister, Dorene Prinzo, held his memory close, adorning her family’s home in New Jersey with pictures of the older brother whom she had lovingly called “Royzy.” “My daughters all know how great their uncle was,” she says.

And then, when her brother had been gone for four decades, she learned of a new remembrance of him. In 2005, Roy’s friend James Flaherty, FCRH ’69, had established a scholarship in honor of the fellow Brooklynite with whom he had commuted to campus. The scholarship goes to students who excel academically and show strong leadership. “He is exactly the kind of person Fordham should remember,” says Flaherty, who, according to Prinzo, had done “such a wonderful thing” in Roy’s memory.

“Fordham was Roy’s dream college. It’s great that kids are going through Fordham with his name attached to their scholarships,” she says. “It gives Roy another chance for his memory to live on.”