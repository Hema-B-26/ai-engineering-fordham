https://www.fordham.edu/give/recognition-societies/the-doty-society

# The Doty Society

![George Doty](/media/review/content-assets/migrated/images/George_Doty.jpg)

The Doty Society recognizes donors who have given to the University for 20 years or more.

The society is named for the late George E. Doty, FCRH ’38, a former chair of the Board of Trustees who donated every year from 1957 until his death in 2012.

Whether their donations are large or small, Doty Society members give consistently. Their quiet, steady generosity has helped generations of students.

Doty Society members are united by their unwavering support of their alma mater. They give to initiatives as varied as the Fordham Fund, financial aid, athletics, and WFUV.

Gift officers are making appointments to meet with eligible donors to present them with their pins. If you think you may be eligible to be a member of the Doty Society, please contact us.

Rick Turk, J.D.

Executive Director of Development

212-636-6568[[email protected]](/cdn-cgi/l/email-protection#4a383e3f38217b0a2c25382e222b27642f2e3f)