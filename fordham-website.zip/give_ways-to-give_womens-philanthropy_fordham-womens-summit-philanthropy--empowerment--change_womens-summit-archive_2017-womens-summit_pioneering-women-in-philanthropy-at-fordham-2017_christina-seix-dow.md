https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2017-womens-summit/pioneering-women-in-philanthropy-at-fordham-2017/christina-seix-dow

# Christina Seix Dow

**Christina Seix Dow, TMC ’72**, is the founder and president emeritus of Christina Seix Academy, an independent school located in Trenton, New Jersey, that educates underserved children from pre-K through eighth grade. Christina has spent the majority of her career in the financial industry, including founding Seix Investment Advisors, LLC.![Christina Seix Dow pioneering in philanthrophy](/media/review/content-assets/migrated/images/Christina_Seix_Dow.jpg)


At Fordham, she has created three endowed scholarship funds including the Christina Seix Dow Endowed Scholarship Fund and the Dow Graduate Scholarship Fund.

Christina received her bachelor’s degree in mathematics from Fordham University and earned a master’s in mathematics from SUNY Stonybrook. In 2008, Fordham University awarded her a Doctor of Humane Letters, honoris causa. She is a former member of the Fordham University Board of Trustees and served on the board of the Lawrenceville School. Christina, her husband, Robert, and their daughter live in Lawrenceville, New Jersey.