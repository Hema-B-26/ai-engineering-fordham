https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/pioneering-women-in-philanthropy-at-fordham

# 2025 Pioneering Women in Philanthropy at Fordham

The Pioneering Women in Philanthropy Award celebrates the honorees’ professional and trailblazing accomplishments as well as their transformative gifts and service to Fordham University. Their wisdom, remarkable careers, and devotion to Fordham serve as inspiration for the women of the Fordham community to lead lives dedicated to the betterment of the world in which we live.

Meet Our 2025 Honorees: