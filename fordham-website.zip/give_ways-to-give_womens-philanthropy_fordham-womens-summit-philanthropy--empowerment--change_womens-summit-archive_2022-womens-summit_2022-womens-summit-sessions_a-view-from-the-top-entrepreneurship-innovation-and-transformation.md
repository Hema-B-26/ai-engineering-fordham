https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2022-womens-summit/2022-womens-summit-sessions/a-view-from-the-top-entrepreneurship-innovation-and-transformation

# A View From the Top: Entrepreneurship, Innovation, and Transformation

We need innovative thinking in these transformative times. Hear from our panelists on how they’ve led change in their respective industries with courage, grace, and savvy.

![May Adrales](/media/home/departments-centers-and-offices/daur/May_Adrales_400.jpg)


**Moderator: May Adrales, ****Director of the Theatre Program, Fordham University**

![Kathleen Adams](/media/home/departments-centers-and-offices/daur/Kathleen_Adams_400.jpg)


**Kathleen Adams, FCRH '10, GSAS '12, ***Vice President, Digital Director, EvolveMKD; Co-owner, Angel of Harlem Bar/Restaurant*

![Gloria Athanis](/media/home/departments-centers-and-offices/daur/Gloria_Athanis_400.jpg)


**Gloria Athanis, MC '81, ***Owner, Partner, Healthful Habits LLC - Phyter*

![Linda Dunham](/media/home/departments-centers-and-offices/daur/Linda_Dunham_400.jpg)


**Linda Dunham, PCS '82, ***President, Dunham Management Corp.; Owner/Operator, McDonald's restaurants *

![Lauren Sweeney](/media/home/departments-centers-and-offices/daur/Lauren_Sweeney_400.jpg)


**Lauren Sweeney, FCRH '12, ***Co-founder, CEO, DeliverZero*