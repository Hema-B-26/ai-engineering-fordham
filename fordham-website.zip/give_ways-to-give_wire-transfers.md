https://www.fordham.edu/give/ways-to-give/wire-transfers

# Make a Gift Via ACH/Wire Transfer

To make a gift via wire transfer of CASH

To make a tuition payment, please visit ** this page**.

## Wire Transfer Instructions

to Fordham University's Development Bank Account:

BANK OF AMERICA

100 WEST 33rd STREET

NEW YORK, NY 10001

### For Domestic Wire Transfers:

ABA No. 026009593

CREDIT FORDHAM UNIVERSITY

FORDU LC DEV Acct. # 483006925227

### For ACH Transfers:

ABA No. 021000322

CREDIT FORDHAM UNIVERSITY

FORDU LC DEV Acct. # 483006925227

### For International Wire Transfers:

SWIFT No. BOFAUS3N

CREDIT FORDHAM UNIVERSITY

FORDU LC DEV Acct. # 483006925227

**IMPORTANT:** in all cases, please indicate instructions about designation/allocation of gift funds.

For additional information and to notify that a gift has been sent, please contact Nick Monteleone at [[email protected]](/cdn-cgi/l/email-protection#6e000301001a0b020b01000b2e08011c0a060f03400b0a1b) or 212-930-8887, or [[email protected].](/cdn-cgi/l/email-protection#db9f9a8e899a98988f9bbdb4a9bfb3bab6f5bebfae)