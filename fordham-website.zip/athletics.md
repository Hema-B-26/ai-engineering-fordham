https://www.fordham.edu/athletics

# Athletics

For the love of the game.

Whether athlete or fan, you’ll find plenty to cheer about at Fordham University. Our 22 men’s and women’s [varsity sports](http://www.fordhamsports.com/) teams compete big time in a big market.

We are NCAA Division I and play in the Atlantic 10 Conference in baseball, basketball, cross country, golf, indoor and outdoor track, women’s rowing, soccer, softball, swimming and diving, tennis and volleyball. Our football team competes in the Patriot League (NCAA I-FCS). Over the past few years, Fordham has won conference championships in football, women's basketball, men's soccer and softball, with each team advancing to the NCAA playoffs.

But varsity sports isn’t the only outlet for our athletically-inclined students. A variety of [club sports](/athletics/club-sports/) pits Fordham teams against other local colleges and universities, and [intramurals](/athletics/intramurals/) from flag football to dodgeball are a great way to have fun, stay active, and relieve some midterm stress.