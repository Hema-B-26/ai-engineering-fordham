https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2019-womens-summit/2019-womens-philanthropy-summit-panels-and-workshops/2019-womens-philanthropy-summit-moderators/sara-kugel

# Sara Kugel

![Panelist Sara Kugel](/media/review/content-assets/migrated/images/Sara_Kugel.jpg)

Sara Kugel, FCRH ’11

*CBS Sunday Morning*. Raised in Kendall Park, New Jersey, she trained in classical ballet at the prestigious School of American Ballet at Lincoln Center before enrolling at Fordham.

She grew interested in journalism while working at WFUV as a reporter and weekend anchor. In addition to winning a Gracie Award for long-form reporting, she received the National Mark of Excellence Award for radio news reporting from the Society of Professional Journalists in 2010. That experience helped her secure an internship with *CBS Sunday Morning*, which eventually led to a full-time position with the program.

During the past seven years at CBS, Sara has produced nearly 200 pieces, ranging from cover stories to profiles of celebrities, including Bruce Springsteen, Barbra Streisand, and WFUV-supporter Steve Martin.

Sara is currently a pursing a master’s degree in history at Harvard University. She is engaged to fellow Fordham Ram Daniel Murphy, FCRH ’11.