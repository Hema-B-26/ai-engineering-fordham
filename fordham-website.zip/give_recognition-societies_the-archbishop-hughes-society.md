https://www.fordham.edu/give/recognition-societies/the-archbishop-hughes-society

# The Archbishop Hughes Society


![Archbishop Hughes and Magis Societies logo](/media/home/departments-centers-and-offices/give/Archbishop-Hughes-and-Magis-Societies-logo.jpg)

![Archbishop John Hughes Founder of Fordham](/media/review/content-assets/migrated/images/Hughes_painting_LG.jpg)

Fordham University gratefully recognizes those individuals and institutions whose lifetime support of the University through outright gifts and pledges totals $1 million or more.

Through their extraordinary generosity and leadership, they have brought focus to our founder's vision and built a foundation for future generations of Fordham students. Their ongoing support provides both the inspiration and leadership necessary to help the University realize its greatest dreams, as an institution dedicated to wisdom and learning in the service of others. We thank them for their lifetime of loyal support.

Call 212-636-6550 or email