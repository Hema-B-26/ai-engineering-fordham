https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2017-womens-summit/pioneering-women-in-philanthropy-at-fordham-2017

# Pioneering Women in Philanthropy at Fordham 2017

The inaugural Pioneering Women in Philanthropy at Fordham honorees have each supported Fordham students and scholarships in unique and creative ways. We celebrate their leadership and generosity.

The inaugural Pioneering Women in Philanthropy at Fordham honorees have each supported Fordham students and scholarships in unique and creative ways. We celebrate their leadership and generosity.