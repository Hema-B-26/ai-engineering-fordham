https://www.fordham.edu/give/celebrating-donors/founders-dinner/founders-award-recipients

# Founder's Award Recipients

## 2026

Meaghan Jarensky Barakett ’16 MS and Brett Barakett

Boniface A. Zaino ’65 and Alison Zaino

## 2025

Henry S. Miller ’68, PAR

Cathy E. Minehan

David M. Tanen ’96 JD

## 2024

John L. Lumelleau ’74 and Loretta Franklin Lumelleau

Robert J. O’Shea ’87, PAR, and Michele K. O’Shea ’88, PAR

## 2023

Robert D. Daleo ’72 and Linda Daleo

Thomas M. Lamberti ’52 and Eileen Lamberti

Vincent E. “Vin” Scully ’49*

## 2021

Emanuel (Manny) Chirico ’79, PAR, and Joanne M. Chirico, PAR

Joe Moglia ’71

## 2020

Jane M. Flaherty, PAR*

Alex Trebek, PAR, and Jean Trebek, PAR

## 2019

Solon P. Patterson and Marianna R. Patterson

Joel I. Picket and Joan Picket

Dennis G. Ruppel ’68 and Patricia Ann Ruppel

## 2018

John R. Costantino ’67, ’70 JD, PAR, and Barbara Costantino, PAR

William J. Loschert, KSG, ’61

Norma L. Tognino, PAR*

## 2017

Carolyn Dursi Cunniffe ’71 PhD

Stephen J. McGuinness ’82, ’91 MBA, PAR

## 2016

George E. Doty Sr. ’38, PAR*, and Marie Ward Doty, PAR*

John D. Feerick ’58, ’61 JD, PAR, and Emalie P. Feerick, PAR

Brian W. MacLean ’75, PAR, and Kathleen H. MacLean ’75, PAR

His Eminence Cardinal Timothy Dolan, Archbishop of New York, ’12 Hon. LHD

## 2015

Edward M. Stroz ’79 and Sally Spooner

William J. Toppeta ’70, PAR, and Debra J. Toppeta, PAR

## 2014

Thomas A. Moore ’72 JD, PAR, and Judith Livingston Moore, PAR

William S. Stavropoulos ’61 PhD and I. Linda Stavropoulos

## 2013

E. Gerald Corrigan ’65 MA, ’71 PhD

John Ryan Heller, PAR

Patricia Anne Heller, PAR

## 2012

Darlene Luccio Jordan, ’89

John N. Tognino ’75, PAR

## 2011

James P. Flaherty ’69, PAR

James J. Houlihan ’74, PAR

## 2010

Maurice J. Cunniffe ’54

Mario J. Gabelli ’65

Regina M. Pitaro ’76

## 2009

James E. Buckman ’66, PAR

John P. Kehoe ’60, ’85

## 2008

Robert E. Campbell ’55

Herbert A. Granath ’54, ’55 MA

## 2007

Kim Bepler ’22 Hon. LHD

Stephen E. Bepler ’64

## 2006

Rose Marie Bravo, CBE, ’71

Paul B. Guenther ’62

## 2005

Angelo R. Mozilo ’60

Charles Osgood ’54, PAR

## 2004

Mary Higgins Clark ’79

General (R.) Jack M. Keane ’66

## 2003

Joseph A. O’Hare, SJ, ’68 PhD

## 2002

His Eminence Cardinal Avery Dulles, SJ, ’12 Hon. LittD

Wellington T. Mara ’37, PAR

William D. Walsh ’51, PAR

* posthumous recipients