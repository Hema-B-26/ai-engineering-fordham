https://www.fordham.edu/veterans/student-veterans-of-america

# Student Veterans of America

The Student Veterans of America (SVA) is open to all Fordham Military connected students. Our goal is to provide a vibrant and professional community where our RamVet community can come together and achieve success. [Meet the Student Veterans of America at Fordham team.](/veterans/student-veterans-of-america/svaf-leadership/#d.en.172216)

## Being a Military Connected Student at Fordham

Fordham University is committed to excelling all of its military connected students. We fully participate in the Yellow Ribbon program with the VA, which provides you with 100% coverage of your tuition as an eligible military connected student using the Post 9/11 GI Bill. Why not further your education at Fordham if everything is covered?

Participate in a wide array of events such as Fordham football tailgates, socials, internship/employment fairs, resume/interview workshops, Yankees games, parades, volunteer opportunities and more.

##### Contact us at [[email protected]](/cdn-cgi/l/email-protection#5a090c1b1c1a3c35283e323b37743f3e2f7a)