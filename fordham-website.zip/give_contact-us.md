https://www.fordham.edu/give/contact-us

# Contact Development and University Relations

For general inquiries, please contact us at 212-636-6550 or [[email protected]](/cdn-cgi/l/email-protection#83e7e6f5e6efecf3eee6edf7c3e5ecf1e7ebe2eeade6e7f6).

If you would like assistance with making a gift, please contact one of our gift officers:

Arts and Sciences and Professional Schools[Michael De Silva](/cdn-cgi/l/email-protection#58353c3d2b31342e396a183e372a3c303935763d3c2d), Executive Director of Development, Arts and Sciences and Professional Schools, 212-636-7184

Athletics[Jerry Hubshman](/cdn-cgi/l/email-protection#d4bebca1b6a7bcb9b5ba94b2bba6b0bcb5b9fab1b0a1), Senior Director of Athletics Development and Senior Associate Director of Athletics, 212-636-6575

Institutional Giving[Laura Cronin](/cdn-cgi/l/email-protection#3a565948555453540c7a5c55485e525b57145f5e4f), Executive Director, Institutional Giving, 917-687-1466 [Marcy Funaro](/cdn-cgi/l/email-protection#c3aea5b6ada2b1acf283a5acb1a7aba2aeeda6a7b6), Senior Director of Institutional Giving, 212-636-6560

Donor Relations and Stewardship[Robert Smith](/cdn-cgi/l/email-protection#6715140a0e130f27010815030f060a49020312), Assistant Vice President for Donor Engagement and Stewardship, 212-636-7441

The Fordham Fund and President's Club[Hannah Graham](/cdn-cgi/l/email-protection#99f1feebf8f1f8f4a8a8d9fff6ebfdf1f8f4b7fcfdec), Director of Fundraising Communications, 212-636-6502

Gabelli School of Business[Heather Gevertz](/cdn-cgi/l/email-protection#4d252a283b283f39370d2b223f29252c2063282938), Executive Director of Development, Business, 212-930-8891

Gift Planning[Jackie Comesanas](/cdn-cgi/l/email-protection#5c363f3331392f3d323d2f1c3a332e38343d3172393829), Executive Director, Gift Planning, 212-636-7244

Major Gifts[Justine Franklin](/cdn-cgi/l/email-protection#0f65697d6e61646366614f69607d6b676e62216a6b7a), Executive Director of Major Gifts, 212-636-7383

Mission and Public Impact Initiatives[Nancy Totino](/cdn-cgi/l/email-protection#46283229322f282906202934222e272b68232233), Senior Director of Development, Mission and Public Impact Initiatives, 347-992-0827

Parent and Family Philanthropy[Jenn Harris](/cdn-cgi/l/email-protection#563c3e3724243f2567656616303924323e373b78333223), Senior Director of Development, Parent and Family Philanthropy, 212-930-8896

Scholarships and Major Gifts[Robert Smith](/cdn-cgi/l/email-protection#abd9d8c6c2dfc3ebcdc4d9cfc3cac685cecfde), Assistant Vice President for Donor Engagement and Stewardship, 212-636-7441[Michael Boyd](/cdn-cgi/l/email-protection#0d606f6274693a4d6b627f69656c6023686978), Senior Associate Vice President, Development and University Relations, 212-636-6525

School of Law[Karen Gresia](/cdn-cgi/l/email-protection#7d161a0f180e141c3d1b120f19151c1053181908), Executive Director of Development and Strategic Initiatives, Law School, 212-636-7640

WFUV[Lynette Ardis](/cdn-cgi/l/email-protection#45292437212c3605232a37212d24286b202130), Executive Director of Development, WFUV, 212-636-6508