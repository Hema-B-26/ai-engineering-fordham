https://www.fordham.edu/fordham-stories

## Featured Stories

![Smart Woman Securities visits Goldman Sachs.](/media/home/admin-use-only/brand-stories/Smart-Woman-Securities-group-photo-.jpg)


Student Clubs

[This Finance Club Preps Women for Careers on Wall Street](/fordham-stories/campus-and-city-life/this-finance-club-preps-women-for-careers-on-wall-street/)

The name Smart Woman Securities may not be one you’ve heard of, but the brands that this Fordham club works with certainly are—companies like Microsoft, Procter & Gamble, Visa, Goldman Sachs, and Morgan Stanley, to name a few.

![John Garza in a pew at Trinity Church](/media/home/admin-use-only/brand-stories/John-Garza-in-a-pew-at-Trinity-Church.jpg)


Internships

[Doing Work That Matters at NYC’s Iconic Trinity Church](/fordham-stories/campus-and-city-life/doing-work-that-matters-at-nycs-iconic-trinity-church/)

What started as a chance to gain practical work experience has bloomed into a multiyear journey for John Garza. More than just an internship, he’s found a community and a sense of purpose at one of New York City’s most enduring landmarks.