https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2022-womens-summit/2022-womens-summit-sessions/emotional-intelligence-and-leadership

# Emotional Intelligence and Leadership

In this workshop you’ll learn why emotional intelligence is necessary to successfully navigate the workplace, diffuse conflict, and build gratifying relationships.

![Rachel Annunziato](/media/home/departments-centers-and-offices/daur/Rachel_Annunziato_SM.jpg)


**Rachel Annunziato, ***Professor of Psychology, **Associate Dean for Strategic Initiatives, **Fordham College at Rose Hill *