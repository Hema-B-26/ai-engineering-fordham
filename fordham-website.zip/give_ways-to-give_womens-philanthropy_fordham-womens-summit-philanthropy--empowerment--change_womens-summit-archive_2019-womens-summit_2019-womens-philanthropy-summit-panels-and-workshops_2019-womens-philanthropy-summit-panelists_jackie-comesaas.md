https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2019-womens-summit/2019-womens-philanthropy-summit-panels-and-workshops/2019-womens-philanthropy-summit-panelists/jackie-comesaas

# Jackie Comesañas

![Jackie Comesanas](/media/review/content-assets/migrated/images/Jackie_Comesanas-2.jpg)

Jackie Comesañas, FCLC ’83

Previously, Jackie served for almost nine years as the director of gift planning for the Archdiocese of New York, where she was responsible for the planned giving programs of the archdiocese and of New York’s Catholic Charities and Department of Education. Jackie has also held planned giving positions at Columbia University, Lighthouse International, and NYU Langone Health. Before entering the field of development, Jackie worked in the legal departments of Lehman Brothers and JPMorgan, specializing in fixed income securities transactions.

Jackie was a member of the Fordham College at Lincoln Center Board (FCLC) of Advisors from 1991 to 2015. As a board member, Jackie was active in the fundraising efforts related to the Anne Marie Imperio/Charlotte W. Newcombe Foundation Endowed Scholarship Fund. Jackie received her B.A. in history *summa cum laude* from FCLC in 1983 and her J.D. from Columbia University School of Law in 1986.