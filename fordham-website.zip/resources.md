https://www.fordham.edu/resources

# Resources

## Your support network.

More than **2.28 million** library books, nearly **750** academic advisors, just over **1160** wireless hubs, and **a gazillion** cups of coffee support a Fordham education. Take advantage of these resources to make the most of your time here.