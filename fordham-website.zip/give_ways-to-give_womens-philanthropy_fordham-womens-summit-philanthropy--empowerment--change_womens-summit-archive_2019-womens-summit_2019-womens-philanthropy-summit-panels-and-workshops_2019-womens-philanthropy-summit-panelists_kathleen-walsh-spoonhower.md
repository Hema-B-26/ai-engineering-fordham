https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/womens-summit-archive/2019-womens-summit/2019-womens-philanthropy-summit-panels-and-workshops/2019-womens-philanthropy-summit-panelists/kathleen-walsh-spoonhower

# Kathleen Walsh-Spoonhower

![Panelist Kathleen Walsh-Spoonhower](/media/review/content-assets/migrated/images/Kathleen_Walsh.jpg)

Kathleen Walsh-Spoonhower, M.D.

Kathleen grew up in the Douglaston neighborhood of Queens. As the child of two Fordham alumni, she has many memories of visiting the Rose Hill campus for football games. She received her B.A. in history from Boston College, and she is grateful that her undergraduate education was also influenced by the Jesuit value of working to become women and men for others. Kathleen then attended medical school at the Albert Einstein College of Medicine in the Bronx. She is very thankful to Fordham for allowing her to use their peaceful library, where she often studied for her medical school exams. Kathleen stayed in the Bronx for her pediatric residency at the Children’s Hospital at Montefiore before going on to do her pediatric cardiology fellowship at the Columbia and Cornell campuses of NewYork-Presbyterian.

Since 2013 she has enjoyed practicing inpatient and outpatient pediatric cardiology at Stony Brook, as well as getting to teach medical students, residents, and fellows. She has also appreciated the opportunity to participate in mentoring programs for both undergraduate and medical students through the American Medical Women’s Association. She thanks Fordham for allowing her to participate in this year’s Women’s Philanthropy Summit and is excited about the chance to learn from her fellow speakers.