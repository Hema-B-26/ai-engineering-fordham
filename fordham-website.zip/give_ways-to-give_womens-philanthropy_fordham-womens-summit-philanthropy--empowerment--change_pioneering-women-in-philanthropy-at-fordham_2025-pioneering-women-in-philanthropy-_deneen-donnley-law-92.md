https://www.fordham.edu/give/ways-to-give/womens-philanthropy/fordham-womens-summit-philanthropy--empowerment--change/pioneering-women-in-philanthropy-at-fordham/2025-pioneering-women-in-philanthropy-/deneen-donnley-law-92

# Deneen Donnley, LAW '92

![Headshot](/media/home/departments-centers-and-offices/give/Deneen-Donnelly-Headshot.jpg)


Before joining USAA, Donnley worked as the senior vice president, general counsel, and secretary at ING Direct. Prior to that, she served as an attorney for Pepper Hamilton LLP and a staff attorney with the Board of Governors of the Federal Reserve System.

Donnley serves on the boards of directors of M1 Finance, Piedmont Office Realty Trust Inc., the Leadership Council on Legal Diversity (LCLD), Girls Inc. of New York City, and the Fordham Law Alumni Association. In addition, she is a member of the Executive Leadership Council, Athena Alliance, and the Direct Women Board Institute.

A Wharton School of the University of Pennsylvania graduate with a Bachelor of Science in economics, Donnley also received her Juris Doctor degree from Fordham Law.