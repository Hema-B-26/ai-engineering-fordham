https://www.fordham.edu/lawcalendar

Skip to main content
Sign In
Print
Event Community
Sign In
View Type:
Summary View
Grid View
List View
Subscribe
VIEW BY: Next 180
Day
Week
Month
Year
Next 7
Next 14
Next 30
Next 60
Next 90
Next 180
Next 365
<
>
Search
Start Date
End Date
Keyword
Category
Select
Academic Calendar
Access to Justice Initiative
Adjunct Faculty
Admissions
Admitted JD Students
Alternative Dispute Resolution (ADR)
Alumni Relations
Brendan Moore Trial Advocacy Center
Career Planning Center (JD Students)
Center for Judicial Events and Clerkships
Center on Asian Americans and the Law
Center on European Union Law
Center on Law and Information Policy (CLIP)
-Faculty Workshops
-Roundtables
Center on National Security
Center on Race, Law and Justice
CLE Events
Climate and Sustainability
Committee on Diversity in Business Law
Compliance Programs and Events
Corporate Law Center
Dispute Resolution Society (DRS)
Diversity Events
Environmental Law Review
Experiential Programs
Faculty
-Faculty Meetings
-Faculty Workshops
Fashion Law Institute
Feerick Center for Social Justice
Financial Aid
Fordham Business Law Association
Fordham Competition Law Institute (FCLI)
Fordham Law Review
Fordham Sports Law Forum
Global Law Society
Institute on Religion, Law & Lawyer's Work
Intellectual Property Institute
Intellectual Property, Media and Entertainment Law Journal
International & Non-J.D. Programs
International Law Journal
JD Concentrations
-Business & Financial Law
-Int'l, Comparative & Foreign Law
-IP & Information Law
-Litigitation & Dispute Resolution
-Public Interest & Service
Journal of Corporate and Financial Law
Law Library
Legal Writing Program
Leitner Center
LL.M. Program
Media & Entertainment Law Society
Mental Health and Wellness
Moot Court
National Center for Access to Justice
Neuroscience and Law Center
Office of Professionalism
Public Interest Resource Center (PIRC)
Public Programs
Small to Midsize Firm Council
Stein Center for Law and Ethics
Stein Scholars
Student Affairs
-Weekly Brief
Student Bar Association (SBA)
Student Organizations
Student-edited Journals
Tech Events
Urban Law Center
Urban Law Journal
Voting Rights and Democracy Projects
Select Multiple
Location
Select
Lincoln Center Campus
-Fordham University School of Law
--1-01 (Gorman Moot Courtroom)
--1-03 (Moore Trial Court Room)
--2-01A
--2-01B (Bateman)
--2-02 (Costantino)
--2-02A & 2-02B (Costantino)
--2-02A (Costantino)
--2-02A, 2-02B & 2-02C (Costantino)
--2-02B & 2-02C (Costantino)
--2-83 (Soden Lounge)
--2nd Floor Open Space
--2nd Floor Veranda
--3-01
--3-02
--3-03
--3-04
--3-05
--3-06
--3-07
--3-08
--3-09
--3rd Floor Open Space
--4-01
--4-02
--4-03
--4-04
--4-05
--4-06
--4-07
--4-08
--4-09
--4-101 (Office of Student Affairs)
--5-02
--5-03
--6-20
--7-02
--7-03
--7-119
--8-01
--9-01
--9-04
--9-05
--Cronin Cafe (Maloney Library, 6th Floor)
--Geraldine A. Ferraro Clinical Education Center
--LL-100
--LL-100A
--LL-101
--LL-124 (IT Conference Room)
--Lobby
--multiple locations
--Robert Moses Plaza
--Skadden Conference Center
--TBD
--Vasiliou Dining Room
--Zoom Webinar
-Gabelli School of Business
--McNally Amphitheatre
-Leon Lowenstein Center
--12th Floor Lounge
--12th Floor Lounge
--12th Floor President's Lounge
--523
--713
--Generoso Pope Memorial Auditorium
--Glass Atrium (Cafeteria)
--McMahon Hall Lounge 109
--South Lounge (Cafeteria)
Off-Campus Event Venue
Online
-Google Hangouts
-WebEx
-Zoom
Rose Hill Campus
-Keating Hall
-O'Hare Hall
--O'Keefe Commons
-Walsh Library - Flom Auditorium
Westchester Campus
Select Multiple
Wednesday, February 4, 2026 - Monday, August 3, 2026
Submit
Close