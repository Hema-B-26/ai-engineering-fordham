https://www.fordham.edu/fordham-bound?utm_source=1+Fordham+Master+List&utm_campaign=26255770e5-EMAIL_CAMPAIGN_2024_06_12_05_18_COPY_01&utm_medium=email&utm_term=0_-506bd2378d-%5BLIST_EMAIL_ID%5D

# Fordham Bound

![Fordham Bound](/media/home/admin-use-only/images/fordham-bound.jpg)


## Welcome to Fordham!

Congratulations on your acceptance to Fordham! Keep an eye on this page and remember to * check your Fordham email regularly* for the latest on key resources, dates, and information to help you and your family get ready for your first days on campus.