https://www.fordham.edu/school-of-law

# School of Law

### We’re creating a community of compassionate and capable lawyers who have a larger goal in mind: to make a difference for our profession, society, and world.



[Explore life at Fordham Law](/school-of-law/life-at-fordham-law/)

[Explore life at Fordham Law](/school-of-law/life-at-fordham-law/)

#3
in Employment of law school graduates by the top 100 law firms in their New York City offices (AmLaw 100/ALM Legal Compass, 2024).

## Fordham Law School News

## Degree Programs

Whether you are a college graduate with a passion for the law, a working professional looking to transform your career, an international legal professional hoping to gain practical knowledge about the U.S. legal system, or an entrepreneur in need of legal insights to enhance your business decisions, Fordham Law’s graduate degree programs provide what you need to achieve your career aspirations.


Cutting-Edge Insights