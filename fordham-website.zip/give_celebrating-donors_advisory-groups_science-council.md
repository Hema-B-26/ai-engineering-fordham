https://www.fordham.edu/give/celebrating-donors/advisory-groups/science-council

# Science Council

![Group of student reacting to experiment - SM](/media/review/content-assets/migrated/images/fu_093010_036_2.jpg)


The Science Council aims to promote the science, technology, engineering, and mathematics (STEM) departments at our university in an unprecedented manner.

From providing mentors for our students to modernizing our technological capabilities in the science departments, the Science Council reflects Fordham’s renewed commitment to providing our future scientists, physicians, and medical professionals with the tools they need to excel.